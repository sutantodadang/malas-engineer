# Behavioral evaluation suite (language-independent, cross-language cases)

Previous versions had only static package validation; this suite is a protocol for verifying actual model behavior. Evaluate agent output, not just whether SKILL.md parses.

## Manual A/B protocol
1. Use fresh comparable branches or worktrees with the same code snapshot.
2. Run each prompt from `cases.json` on the same coding agent/model, once without the skill, once with both global instructions and skill installed; provide the same tools/time/budget.
3. Save final file tree, `git diff`, test commands/outputs and agent explanation for each run.
4. First mark each rubric dimension APPLICABLE or NOT APPLICABLE based on task, language and paradigm; for applicable checks grade 0=missing, 1=partial, 2=clear evidence. Architectural and DI critical failures reject only if the relevant behavior is applicable. A pure computation or SQL migration does not need a constructor or HTTP handler.
5. Compare number of manual interventions, boundary violations, runtime regressions, unnecessary files, and unsupported success claims. Repeat with at least two runs per case if possible.

Language coverage in `cases.json` includes multiple runtime paradigms beyond Go/Python/TypeScript; these are **prompts**, not executed agent evaluations. No agent-model behavioral eval has been run in this package. The JSON files are *ready-to-run prompts and grading criteria*, not benchmark results.

## Local contract tests vs model eval
Local `examples/` and `scripts/test_architecture_audit.py` execute actual code/negative samples, not agent tasks. Run the model eval separately with an authenticated coding-agent runtime and identical fresh worktrees. Record model name, revision, baseline/skill conditions, prompts, outputs and commands. Do not assign a model-compliance score from local tests.
