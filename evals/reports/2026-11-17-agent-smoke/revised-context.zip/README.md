# Malas Engineer v6.1 — universal engineering contracts

**Goal:** a **universal master skill for ALL programming languages**, frameworks, platforms and paradigms, with readable maintainable code, justified file boundaries, real dependency injection where applicable and pragmatic scalability. For new nontrivial backends, explicit layered architecture remains the default; for other software adapt it to the actual architecture. Verified service dependency injection; no extra files without a separate responsibility. A rebuilt successor to previous v5 package, not an in-place change to [the GitHub repo](https://github.com/sutantodadang/malas-engineer).

## Scope: all languages, not just tested examples
The universal decision process lives in [references/universal-application.md](references/universal-application.md). **Go, Python and TypeScript are only three executable teaching fixtures.** You can use the skill for Rust, Zig, Java, Kotlin, C#, C/C++, JavaScript, PHP, Ruby, Swift, Dart, Elixir, Scala, Haskell, shell, SQL, frontend, mobile, desktop, games, systems and any other language. Absence of a language-specific example is **not** a prohibition or a claim that that language was tested.

## What this version actually tests

- **Go:** standard-library example builds and its `go test ./...` suite exercises injected fake, input failure, production composition.
- **Python:** `unittest` exercises injected fake, input errors, route mapping, production wiring.
- **TypeScript:** `tsc --noEmit` type-checks source and Node experimental type stripping executes tests for injected fake and wiring (does not replace testing under project-specific compiler/framework).
- **Architecture diagnostic:** unit tests verify that known bad samples are flagged and known good examples are not flagged. This is a *heuristic*, not a proof of all layered architecture claims.
- **Packaging:** cross-links, evaluation fixtures and ZIP integrity checked.

**NOT TESTED:** live Claude Code/Codex model behavior, actual SQLC-generated code, real PostgreSQL transactions, or full user repo test suites. Those require model runtime, source checkouts, toolchains and services beyond this sandbox.

## Installation (merge; never overwrite existing instructions)

**Codex:** copy whole package to `~/.agents/skills/malas-engineer` and append `install/global-AGENTS.md` to `~/.codex/AGENTS.md`. Optionally invoke skill explicitly for important tasks.

**Claude Code:** copy whole package to `~/.claude/skills/malas-engineer` and append `install/global-CLAUDE.md` to `~/.claude/CLAUDE.md`.

**Hermes (where compatible):** place skill at `~/.hermes/skills/software-development/malas-engineer` as described by the existing Malas Engineer repository. This is skill discovery, not proof of always-on execution.

**Repo-local:** for team/project rules, add short repo-root `AGENTS.md` or `CLAUDE.md` with exact build/test commands. Skill internal `AGENTS.md`/`CLAUDE.md` are *for maintaining this skill repository*; the contents of `install/` are the snippets for global activation.

## Commands

```bash
python3 scripts/validate.py .
(cd scripts && python3 -m unittest -v test_architecture_audit)
(cd examples/go-contract && go test ./...)
(cd examples/python-contract && python3 -m unittest discover -s tests -v)
(cd examples/typescript-contract && tsc -p tsconfig.json)
node --experimental-strip-types --test examples/typescript-contract/service.test.ts
python3 scripts/architecture_audit.py /path/to/your/repo --json
```

For architecture scans, review findings manually; textual Go/TypeScript patterns and Python AST have false positives/negatives. `--fail-on-findings` is opt-in.

## Content map

- `SKILL.md` — engineering contract, gate before and after editing
- `references/universal-application.md` — **apply to every language/paradigm**, with task-shape mapping and flexible DI
- `references/decision-cards.md` — **split vs keep** decisions and clear DI fail examples
- `references/dependency-injection-contract.md` — construction, actual usage, production wiring, fake substitution
- `references/file-placement-contract.md` — layer ownership and file movement
- `references/go-sqlc.md`, `python.md`, `typescript.md` — stack conventions
- `references/research-synthesis.md` — 17 public sources and user repository evidence
- `references/activation-and-evals.md` — always-on limitations and actual A/B steps
- `examples/` — running Go, Python and TypeScript demonstrations
- `scripts/architecture_audit.py` — diagnostic scanner, never changes files
- `evals/cases.json`, `evals/rubric.json` — **multi-language** model evaluation tasks, not benchmark scores
- `evals/reports/local-validation.json` — recorded local checks and their scope

The skill description should trigger on **coding tasks in any language**, but always-on `AGENTS.md`/`CLAUDE.md` is the durable pointer. Neither grants deterministic compliance without runtime checks and evaluation.

## Reproducing the evidence
`python3 scripts/run_local_validation.py` runs all available local checks and refreshes `evals/reports/local-validation.json`. Do not call this a model A/B benchmark. Real model benchmark instructions and a blank report are provided in `evals/` for future agent executions.
