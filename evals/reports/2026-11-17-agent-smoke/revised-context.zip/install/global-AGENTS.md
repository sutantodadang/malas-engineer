# Malas Engineer — always-on coding contract
For **ALL programming tasks in ANY language or framework** (backend, frontend, mobile, desktop, CLI, systems, scripts, databases and infrastructure), **load and apply the `malas-engineer` skill**. Do not assume a skill is active merely because its name is installed.

**Do not code before mapping** the actual input/boundary -> core behavior -> side-effect/adapters path **when applicable**, identifying ownership of each modified behavior, and selecting file destinations by responsibility. For new nontrivial backends prefer explicit layered architecture; for other software adapt boundaries to the architecture and idioms rather than adding artificial HTTP layers.

**Explicit dependency supply is mandatory for effectful collaborators where applicable:** constructors, function parameters, traits, callables or framework DI must actually be used; production assembly supplies real implementations, tests can substitute controlled fakes. No hidden global I/O clients, no service locator, and no presentation boundary that bypasses application behavior when layering is warranted. Go SQLC may satisfy narrow service-owned interfaces directly; Go/Python/TypeScript examples are **illustrative, not a limitation**. Do not force constructors, repositories or controllers onto pure functions or tiny scripts.

**Split by responsibility and dependency direction**, not line count; keep cohesive small private helpers together. Never add meaningless wrappers, one-function files, generic utils or interfaces without a consumer need. Honor user-required files and signatures. For existing code, edit the smallest necessary scope.

Tests and verification are evidence, not decoration: exercise relevant negative paths; check diff; report exact commands, failures and unrun checks. No invented APIs, findings, or success claims. Write plain readable technical English; ask only when a missing fact makes correct implementation impossible.

Before completion: verify actual collaborator wiring (where applicable), ownership boundaries, split/keep decisions, behavior tests and risk. Follow `malas-engineer/references/verification.md` when available.
