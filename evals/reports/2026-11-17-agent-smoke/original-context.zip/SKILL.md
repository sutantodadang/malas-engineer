---
name: malas-engineer
description: "Universal, language-agnostic engineering execution discipline for coding agents across ALL programming languages, frameworks and paradigms. Enforces clear responsibility boundaries, real dependency injection where applicable, reasoned file placement, maintainable scalable code, minimal diffs, honest testing and double-checking. Read before coding in any stack."
---
# Malas Engineer — universal engineering execution contract (6.1)

**Be lazy about unnecessary work, never about engineering quality.** Write for human maintainers. This is a **behavioral contract**, not a catalog of buzzwords.

## Scope and priority
Apply to **ALL programming languages, ecosystems and code artifacts**, including Go, Python, TypeScript, JavaScript, Java, Kotlin, C#, C/C++, Rust, Zig, PHP, Ruby, Swift, Dart, Scala, Elixir, functional languages, shell scripts, SQL, frontend, desktop, mobile, CLI, infrastructure and embedded work. **Never restrict these instructions to the three executable examples.** The same core quality requirements apply regardless of language, while architecture patterns must fit the actual runtime and idioms. User requirements and repository constraints win over stylistic defaults. For new nontrivial **backend applications**, explicit layered architecture is the default; for other software adapt boundaries to its architectural paradigm. For existing applications, preserve public contracts and improve only affected boundaries. Do not silently rewrite a whole repository.

**Principle inheritance:** correctness, readability, maintainability, pragmatic scalability, DRY/KISS/YAGNI, ownership, focused files, honest evidence, testability and verification are universal. **Patterns are conditional:** a network application may need presentation/application/persistence boundaries; a pure library may not need controllers or repositories; a functional language may use dependency parameters instead of classes; a single-file script must not be turned into a framework just to satisfy a template. First detect language, paradigm, framework and existing project conventions. See [universal application and adaptation](references/universal-application.md).

## Mandatory pre-edit gate (do not start typing code before this)
1. **Read:** the relevant entry point, feature code, callers, contracts, current tests, schema, and build/dependency configuration. Search before creating helpers.
2. **Map one actual execution path:** entry point -> boundary/interface -> core behavior -> effects/adapters **as applicable**. On HTTP backends, use handler/controller -> service -> persistence/client. In other kinds of software, identify the corresponding actual boundary (CLI command, UI screen, message handler, exported library API, scheduler, compiler pass). Label relevant responsibilities **present / missing / mixed** and cite real files. A layer that is not meaningful is **not applicable**, not missing. Never invent a file you have not seen.
3. **Name the responsibility:** what behavior changes, its owning feature, its side effects, its consumers, and its failure modes. Determine whether the software is a backend, UI, library, CLI, script, systems component, database migration, test or infrastructure asset; do not assume HTTP or a database exists.
4. **Choose destinations:** for each added or changed responsibility write `Responsibility -> destination file -> why here -> dependencies`. Apply [decision-cards](references/decision-cards.md) and [file-placement-contract](references/file-placement-contract.md). No 'one file for everything' and no 'one file per function'.
5. **Draw dependency ownership:** who constructs each service and adapter? Which injected contract does each service need? Apply [dependency-injection-contract](references/dependency-injection-contract.md). If this cannot be answered, fix the design before implementing.
6. **Test plan:** identify a failing regression/contract test when feasible, relevant integration checks, and compatibility impact.

For a one-line low-risk correction, compress the gate into a few internal notes; do not generate long design documents. For new API features or mixed-boundary refactors, show a compact plan before editing.

## Non-negotiable architecture contract (when these responsibilities exist)
**Do not enforce HTTP-specific layers in non-HTTP software.** For new nontrivial backends prefer explicit controller/handler -> service/use-case -> persistence/adapter boundaries. For frontend, desktop, mobile and other applications, translate the roles to input/presentation -> application/state/workflow -> domain -> infrastructure/side effects. For libraries and small scripts, use the minimum meaningful separation. See [universal application](references/universal-application.md).
- **Transport handler** owns HTTP/RPC decoding, boundary validation, authentication context, status/response mapping. It calls a service for business behavior. No SQL, ORM query, or business workflow in handlers.
- **Service/use case** owns application workflow, business decisions, authorization, transaction orchestration policy, and calls injected dependencies. It **does not instantiate** repositories, DB pools, HTTP clients, or global dependency containers. Avoid framework HTTP exceptions in reusable services.
- **Repository/adapters** own database queries, transactions as necessary, storage mapping, and remote I/O. They do not decide business policies. Distinguish a repository from a remote client/port; avoid naming everything repository.
- **Domain** owns complex invariants and business types when necessary; avoid empty domain scaffolding for CRUD.
- **Composition root / assembly boundary** (main/bootstrap/framework DI setup/function caller) owns creation of stateful external adapters, passing them to code that uses them. No hidden service locator in business logic. **Explicit dependency injection is mandatory for services with external dependencies where the language supports it; choose constructor injection for object-oriented services, parameter/function injection or idiomatic framework DI for other paradigms.** Pure functions and simple stateless routines remain functions; do not invent class constructors or interfaces to fake DI.
- **Dependency direction:** input/presentation -> application behavior -> owned ports/contracts -> adapters, **where those roles exist**; a composition root knows implementations. Prefer small consumer-owned interfaces/protocols/callables if needed. Avoid cycles and hidden mutable global dependencies; honor language-specific ownership/lifetime conventions.
- **Existing code:** preserve conventions except at the changed seam. Do not claim a complete Clean Architecture migration for a localized edit.

## Actual rules for splitting and keeping files
Use [references/file-placement-contract.md](references/file-placement-contract.md) for the decision table and examples. Rules in priority order:
1. If code **crosses a layer boundary**, place it in the owning layer file, even when short. Never keep DB I/O in a handler for fewer files.
2. Split when there are **different reasons to change**, dependency sets, independently testable policies, or clearly different named responsibilities (e.g. `retry_policy.go` vs `service.go`).
3. Keep tightly coupled private helpers together if they share one concern, dependency set and lifecycle. Do not create a file solely because the function is long or a fixed line count is reached.
4. Prefer **feature modules** with predictable filenames over global dumping grounds. Never auto-create an empty layer folder; only create files with real code.
5. Before extraction, prove which consumers use it. Avoid generic `utils`, `helpers`, `common`, `manager`, `base_repository` without a narrow domain-specific contract.
6. For any borderline decision, choose the option that allows a new maintainer to answer **where is HTTP, where is the business rule, where is I/O, where is the test?** in under a minute.

## Dependency injection is behavior, not vocabulary (adapt to language/paradigm)
- Show **construction and use**, not just an interface declaration. A service accepting a dependency but ignoring it FAILS.
- Inject side-effecting collaborators through **explicit constructors, function parameters, closures, traits, protocols, interfaces, framework-supported DI or equivalent idiomatic mechanisms**. Do not force class-based injection into Rust/Zig/C/functional languages. Production assembly must provide actual collaborators; tests must substitute deterministic fakes or controlled adapters without requiring live infrastructure in core unit tests. Verify collaborator usage, not syntax alone.
- An interface is not automatically required for every class/function. In Go prefer narrow consumer-defined interfaces (sqlc can satisfy one directly); in TypeScript structural contracts; in Python Protocol where useful; in Rust traits/functions; in Java/Kotlin/C# constructor-injected services with appropriate lifetimes; in Zig/C explicit structs, context or function pointers where useful; in functional languages pure functions with effectful collaborators passed at boundaries. These are **examples, not an exhaustive supported-language list**. Avoid handwritten pass-through repository wrappers that add no meaning.
- Injection must distinguish **external side effects** (DB, clock, HTTP, queue) from pure values. Transaction ownership and lifetime must be explicit.
- Review with [references/dependency-injection-contract.md](references/dependency-injection-contract.md) and the language-specific examples.

## Implementation and quality contract (anti-hallucination applies across ALL languages)
- DRY only for the **same semantic behavior**; KISS/YAGNI over speculative patterns. Correctness, security, human readability and maintainability outweigh cleverness or tiny file count.
- No invented APIs, fields, acceptance criteria, test output, performance results, or repository findings. Mark **VERIFIED**, **INFERRED**, **UNKNOWN** explicitly where material; ask one targeted question only when a missing choice would cause incompatible or unsafe implementation. Otherwise state assumption and choose reversible safe behavior.
- Minimal diff: touch only required code and tests; never silently reformat other modules, change libraries, or redesign unrelated layers. Fix a local architectural breach only if needed for the requested behavior, or propose it separately.
- Tests: regression test first where feasible; unit tests for pure policies and service behavior, integration tests for real DB/transactions/HTTP boundaries, E2E for critical journeys. Do not add meaningless mock-only coverage; verify failure paths, edge cases, idempotency and concurrency when relevant. **Never claim test passes unless you ran it.**
- Security and reliability: validate input, scope data access, parameterize queries, protect secrets, apply timeouts/cancellation, check errors, use correct money/date semantics, respect compatibility.
- Technical writing: short, unambiguous plain English inspired by ASD-STE100 clarity principles; do not claim formal STE100 conformance.

## Evidence-driven reference implementations
Do not invent conventions from memory. Inspect the current repository and language/framework official conventions. Executable examples at [examples/README.md](examples/README.md) currently cover **Go, Python, TypeScript as illustrative samples only**; absence of an example does **not** change universal applicability. Translate contracts to the project language and paradigm; do not copy syntax or layers mechanically. These are standard-library stand-ins, not evidence of a real SQLC/ORM deployment. Prove service injection with an actual fake-call test and verify the production composition path. For splitting decisions consult [decision-cards](references/decision-cards.md), not file length.

## Failure-triggered course correction
If a design produces **fake injection**, direct DB access from handlers, or a service that constructs its external client, fix the boundary before adding another feature. If a code edit touches unrelated files, remove that work unless explicitly requested. If tests fail, diagnose the first causal failure; never alter tests only to make them green. Repeat acceptance and review after the fix. Automatic scanners provide diagnostics, not blanket proof; review actual source code.

## Mandatory completion gate
1. Inspect full diff and inspect actual path entry -> service -> adapter. Prove the handler delegates; prove service depends on injected collaborators; prove wiring instantiates the graph.
2. Challenge every new file: distinct responsibility? Correct owner? Can two files be combined without mixed concerns? Challenge every remaining large file: are multiple independent responsibilities mixed?
3. Inspect error/negative paths, authorization, resource lifetime, idempotency and transaction boundaries where applicable.
4. Run relevant formatting/lint/typecheck/tests/integration; record commands and results. When blocked, report **NOT RUN**, with reason. `git diff --check` is useful, not a substitute for tests.
5. Report compactly: changed files and reason; DI wiring; tests actually run/results; known risks. Never say 'done' if core acceptance criteria are unverified.

## Read references only when triggered
- **Every task in any language:** [universal application and adaptation](references/universal-application.md) whenever stack conventions or architecture mapping is uncertain
- Any new file/extraction: [decision-cards](references/decision-cards.md), [file-placement-contract](references/file-placement-contract.md)
- Any service, effectful function or external dependency in **any language**: [dependency-injection-contract](references/dependency-injection-contract.md)
- Go or sqlc, when relevant: [go-sqlc](references/go-sqlc.md)
- TypeScript, when relevant: [typescript](references/typescript.md)
- Python/Django/FastAPI, when relevant: [python](references/python.md)
- Other languages/frameworks: [universal application and adaptation](references/universal-application.md), plus the repository’s own idioms; **do not assume no support because a language-specific reference is absent**
- Choosing tests and code review: [verification](references/verification.md)
- Real evidence and online skill research: [research-and-provenance](references/research-and-provenance.md)
- Evaluation: [evals/README.md](evals/README.md)
- Skill installation and actual behavior evaluation: [activation-and-evals](references/activation-and-evals.md)
- More than 15 curated external practice sources and user repo evidence: [research-synthesis](references/research-synthesis.md)
- Executable contract examples (Go, Python, TypeScript): [examples/README.md](examples/README.md)
