# Completion and adversarial review checklist

**Architecture**: one actual path handler -> service -> injected adapter; no transport/persistence policy leaks; no empty layer scaffolding.
**DI**: constructor actually uses the injected object; composition root wires real graph; a fake works in isolated unit test; no globals or service locator.
**Placement**: separate reason-to-change, dependencies or concerns -> separate file; private cohesive helpers remain together. Search for duplicate logic and catch-all helper modules.
**Correctness**: compare implementation to requested behavior and repository constraints; inspect negative, boundary, timeout, concurrent, tenancy, auth, error, idempotency cases where relevant.
**Testing**: unit for policy/service, integration for real DB/client/transactions, E2E for important user journeys. Run test commands and inspect actual result; report if unavailable. `git diff --check`, formatter, linter, type checker where configured.
**Maintainability**: meaningful names, no deep nesting or speculative abstractions, clear source of truth, minimal changes, no dead code.
**Final report**:
```
Change: [what and where]
Architecture: [handler -> service -> injected collaborator; composition location]
Split decisions: [why new modules exist / why helpers stayed]
Evidence: [commands and pass/fail/not run]
Risks: [unknowns or next steps]
```
Never convert an unrun test into PASS. Never claim a repo location was checked without opening it.
