#!/usr/bin/env python3
"""Tests both known-bad and known-good files. Scanner findings are not proof."""
import unittest
from pathlib import Path
from architecture_audit import python_scan, other_scan, scan

ROOT=Path(__file__).resolve().parents[1]
class ArchitectureAuditTests(unittest.TestCase):
    def test_service_constructs_adapter_and_ignores_injection(self):
        findings = python_scan(ROOT/'evals/fixtures/bad/order_service.py')
        self.assertEqual({x['rule'] for x in findings}, {'SERVICE_CREATES_ADAPTER', 'INJECTED_BUT_UNUSED'})
    def test_handler_direct_db_operation(self):
        self.assertIn('HANDLER_PERSISTENCE_IO', {x['rule'] for x in python_scan(ROOT/'evals/fixtures/bad/order_handler.py')})
    def test_go_new_repo_bad(self):
        self.assertIn('SERVICE_CREATES_ADAPTER', {x['rule'] for x in other_scan(ROOT/'evals/fixtures/bad/payment_service.go')})
    def test_typescript_new_repo_bad(self):
        self.assertIn('SERVICE_CREATES_ADAPTER', {x['rule'] for x in other_scan(ROOT/'evals/fixtures/bad/book_service.ts')})
    def test_good_service_not_flagged(self):
        self.assertEqual(python_scan(ROOT/'evals/fixtures/good/order_service.py'), [])
    def test_real_python_contract_example_not_flagged(self):
        self.assertEqual(scan(ROOT/'examples/python-contract'), [])
    def test_real_go_contract_example_not_flagged(self):
        self.assertEqual(scan(ROOT/'examples/go-contract'), [])
    def test_real_typescript_contract_example_not_flagged(self):
        self.assertEqual(scan(ROOT/'examples/typescript-contract'), [])

if __name__ == '__main__': unittest.main()
