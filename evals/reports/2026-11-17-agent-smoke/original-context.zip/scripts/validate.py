#!/usr/bin/env python3
"""Package shape, link, test-case, and reference validator, not an agent benchmark."""
import json, re, sys
from pathlib import Path
root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
skill = root/'SKILL.md'
assert skill.is_file(), 'missing SKILL.md'
s = skill.read_text(encoding='utf-8')
assert s.startswith('---\n'), 'missing frontmatter'
header=s.split('---',2)[1]
assert re.search(r'^name:\s*malas-engineer\s*$',header,re.M),'invalid skill name'
assert re.search(r'^description:\s*.+',header,re.M),'missing description'
assert len(s.splitlines()) < 500,'skill too long'
assert all(k in s.lower() for k in ('composition root','dependency injection','split','unit test','anti-hallucination')),'critical rule missing'
for rel in [
 'README.md','AGENTS.md','CLAUDE.md','install/global-AGENTS.md','install/global-CLAUDE.md',
 'evals/cases.json','evals/rubric.json','references/decision-cards.md',
 'references/research-synthesis.md','references/activation-and-evals.md','references/universal-application.md',
 'examples/go-contract/app/service.go','examples/go-contract/app/service_test.go',
 'examples/python-contract/catalog/service.py','examples/python-contract/tests/test_service.py',
 'examples/typescript-contract/service.ts','examples/typescript-contract/service.test.ts',
 'scripts/architecture_audit.py','scripts/test_architecture_audit.py',
]: assert (root/rel).is_file(),f'missing {rel}'
# Check links for all local Markdown pages, including the main skill.
for path in root.rglob('*.md'):
    content=path.read_text(encoding='utf-8')
    for link in re.findall(r'\]\(([^)]+)\)',content):
        if link.startswith(('https://','http://','#','mailto:')): continue
        candidate=(path.parent/link.split('#')[0]).resolve()
        assert candidate.exists(),f'broken link {link} from {path.relative_to(root)}'
cases=json.loads((root/'evals/cases.json').read_text(encoding='utf-8'))
assert len(cases)>=30 and len({x['id'] for x in cases}) == len(cases),'eval prompt count/IDs'
assert all(k in s.lower() for k in ('all programming languages', 'functional', 'not applicable')), 'universal language scope missing'
assert all(k in (root/'install/global-AGENTS.md').read_text().lower() for k in ('any language', 'all programming')), 'global universal scope missing'
assert all(k in (root/'references/universal-application.md').read_text().lower() for k in ('rust', 'zig', 'java', 'kotlin', 'php', 'haskell', 'shell')), 'cross-language adaptation missing'
assert all(x['prompt'] and x['critical'] for x in cases),'incomplete case'
rubric=json.loads((root/'evals/rubric.json').read_text(encoding='utf-8'))
assert len(rubric['dimensions'])>=5
sources=(root/'references/research-synthesis.md').read_text(encoding='utf-8')
assert len(re.findall(r'https://',sources))>=20, 'insufficient source references'
print(f'STATIC PACKAGE VALIDATION PASSED: {len(cases)} model scenarios; links, examples and source index present')
