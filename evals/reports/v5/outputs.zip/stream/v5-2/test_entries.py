import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from contextlib import chdir

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_open_text_stream(self):
        stream = io.StringIO('skip\n\n"café"\n')
        stream.readline()
        self.assertEqual(read_entries(filename=stream), ["café"])
        self.assertFalse(stream.closed)
        bad = io.StringIO("bad json")
        with self.assertRaises(json.JSONDecodeError):
            read_entries(bad)
        self.assertFalse(bad.closed)

    def test_file_contract(self):
        with tempfile.TemporaryDirectory() as folder, chdir(folder):
            path = Path("-")
            path.write_text('1\n\n"café"\n', encoding="utf-8")
            for filename in (path, "-"):
                self.assertEqual(read_entries(filename=filename), [1, "café"])
            with self.assertRaises(FileNotFoundError):
                read_entries("missing")

    def test_file_and_pipe(self):
        cli = Path(__file__).with_name("cli.py").resolve()
        cases = [
            ('\n"café"\r\n\u2003\n42'.encode(), None),
            (b"oops", b"JSONDecodeError"),
            (b'"\xff"', b"UnicodeDecodeError"),
        ]
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "export"
            for data, error in cases:
                path.write_bytes(data)
                for arg in (str(path), "-"):
                    with self.subTest(arg=arg, data=data):
                        result = subprocess.run(
                            [sys.executable, cli, arg], input=data, capture_output=True,
                            env={**os.environ, "PYTHONIOENCODING": "cp1252:replace"},
                        )
                        if error:
                            self.assertNotEqual(result.returncode, 0)
                            self.assertIn(error, result.stderr)
                        else:
                            self.assertEqual(result.returncode, 0, result.stderr)
                            self.assertEqual(result.stdout.splitlines(), [b"2"])
