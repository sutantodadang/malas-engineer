# Entry counter

`python cli.py FILE` counts records in a UTF-8 JSON Lines file. Blank lines are ignored. The public `read_entries(filename)` function also accepts keyword calls and path-like objects. A file literally named `-` is a valid library input.

Use `python cli.py -` to count a UTF-8 export from stdin. You can also pass an open text stream to `read_entries` to read from its current position. The caller owns the stream and closes it.
