import argparse
import sys

from entries import read_entries


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("filename", help="UTF-8 JSON Lines file, or - for stdin")
    args = parser.parse_args(argv)
    source = args.filename
    if source == "-":
        source = sys.stdin
        if hasattr(source, "reconfigure"):
            source.reconfigure(encoding="utf-8", errors="strict", newline=None)
    print(len(read_entries(source)))


if __name__ == "__main__":
    main()
