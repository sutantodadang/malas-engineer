import io
import json
import subprocess
import sys
import unittest
from contextlib import chdir
from pathlib import Path
from tempfile import TemporaryDirectory

from entries import read_entries


CLI = Path(__file__).with_name("cli.py").resolve()


class EntryTests(unittest.TestCase):
    def test_borrowed_stream_reads_from_current_position(self):
        with io.StringIO('skipped\n\n{"id": 1}\nfalse\n') as source:
            source.readline()
            self.assertEqual(read_entries(filename=source), [{"id": 1}, False])
            self.assertFalse(source.closed)

    def test_parse_failure_leaves_borrowed_stream_open(self):
        with io.StringIO("invalid\n") as source:
            with self.assertRaises(json.JSONDecodeError):
                read_entries(source)
            self.assertFalse(source.closed)

    def test_paths_and_cli_pipe(self):
        data = '"café"\n  \n42\n'
        with TemporaryDirectory() as directory, chdir(directory):
            path = Path("-")
            path.write_text(data, encoding="utf-8")
            for filename in (path, "-"):
                self.assertEqual(read_entries(filename=filename), ["café", 42])
            with self.assertRaises(FileNotFoundError):
                read_entries("missing")
            path.rename("export.jsonl")
            for argument, stdin in (("export.jsonl", ""), ("-", data)):
                result = subprocess.run(
                    [sys.executable, "-X", "utf8", CLI, argument],
                    input=stdin, encoding="utf-8", capture_output=True, check=True,
                )
                self.assertEqual(result.stdout, "2\n")
