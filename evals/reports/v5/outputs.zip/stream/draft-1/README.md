# Entry counter

`python cli.py FILE` counts records in a UTF-8 JSON Lines file. Use `python cli.py -` to count records from standard input. Blank lines are ignored.

The public `read_entries(filename)` function accepts paths, path-like objects and open text streams, including by keyword. It reads streams from their current position and leaves them open. A file literally named `-` is a valid library input.
