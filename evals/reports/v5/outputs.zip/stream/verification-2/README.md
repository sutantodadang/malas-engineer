# Entry counter

`python cli.py FILE` counts records in a UTF-8 JSON Lines file. Blank lines are ignored. The public `read_entries(filename)` function also accepts keyword calls and path-like objects. A file literally named `-` is a valid library input.

`python cli.py -` counts records from standard input. Pass an open text stream to `read_entries` to read from its current position. The caller keeps ownership of the stream.
