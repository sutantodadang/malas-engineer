import json
from contextlib import nullcontext
from os import PathLike
from pathlib import Path


def read_entries(filename):
    if not isinstance(filename, (str, PathLike)) and hasattr(filename, "read"):
        reader = nullcontext(filename)
    else:
        reader = Path(filename).open(encoding="utf-8")
    with reader as source:
        return [json.loads(line) for line in source if line.strip()]
