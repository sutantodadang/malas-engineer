import io
import json
import subprocess
import sys
import unittest
from contextlib import chdir
from pathlib import Path
from tempfile import TemporaryDirectory

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_stream_reads_from_current_position_and_stays_open(self):
        stream = io.StringIO('skip\n\n{"name": "café"}\n')
        stream.readline()
        self.assertEqual(read_entries(filename=stream), [{"name": "café"}])
        self.assertFalse(stream.closed)

    def test_malformed_stream_stays_open(self):
        stream = io.StringIO("bad json")
        with self.assertRaises(json.JSONDecodeError):
            read_entries(stream)
        self.assertFalse(stream.closed)

    def test_file_compatibility(self):
        with TemporaryDirectory() as folder, chdir(folder):
            Path("-").write_text('"café"\n', encoding="utf-8")
            self.assertEqual(read_entries(filename="-"), ["café"])
            self.assertEqual(read_entries(Path("-")), ["café"])
            with self.assertRaises(FileNotFoundError):
                read_entries("missing")
            Path("-").write_text("bad json", encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError):
                read_entries("-")

    def test_cli_file_and_pipe(self):
        cli = Path(__file__).with_name("cli.py")
        records = '1\n\n{"count": 2}\n'
        with TemporaryDirectory() as folder:
            path = Path(folder, "records.jsonl")
            path.write_text(records, encoding="utf-8")
            for source in (str(path), "-"):
                with self.subTest(source=source):
                    result = subprocess.run(
                        [sys.executable, cli, source], cwd=folder, input=records,
                        text=True, capture_output=True, check=True,
                    )
                    self.assertEqual(result.stdout, "2\n")
