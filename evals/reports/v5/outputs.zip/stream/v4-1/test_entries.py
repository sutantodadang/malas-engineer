import io
import json
import subprocess
import sys
import unittest
from contextlib import chdir
from pathlib import Path
from tempfile import TemporaryDirectory

from entries import read_entries


CLI = Path(__file__).with_name("cli.py").resolve()


class EntryTests(unittest.TestCase):
    def test_stream_reads_from_current_position_and_stays_open(self):
        with io.StringIO('skip\n\n{"id": 1}\nnull\n') as stream:
            stream.readline()
            self.assertEqual(read_entries(filename=stream), [{"id": 1}, None])
            self.assertFalse(stream.closed)

    def test_malformed_stream_keeps_its_owner(self):
        with io.StringIO("bad json") as stream:
            with self.assertRaises(json.JSONDecodeError):
                read_entries(stream)
            self.assertFalse(stream.closed)

    def test_filename_contract(self):
        with TemporaryDirectory(dir=".") as directory, chdir(directory):
            Path("-").write_text('"café"\n', encoding="utf-8")
            for filename in ("-", Path("-")):
                self.assertEqual(read_entries(filename=filename), ["café"])
            with self.assertRaises(FileNotFoundError):
                read_entries("missing")
            Path("-").write_text("{", encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError):
                read_entries("-")
            for invalid in (["1"], io.BytesIO(b"1")):
                with self.assertRaises(TypeError):
                    read_entries(invalid)

    def test_cli_counts_stdin_and_file(self):
        records = '\n1\n  \n{"id": 2}\n'
        with TemporaryDirectory(dir=".") as directory:
            Path(directory, "records").write_text(records, encoding="utf-8")
            for argument in ("records", "-"):
                with self.subTest(argument=argument):
                    result = subprocess.run(
                        [sys.executable, CLI, argument], input=records, text=True,
                        capture_output=True, cwd=directory, check=True,
                    )
                    self.assertEqual(result.stdout, "2\n")
