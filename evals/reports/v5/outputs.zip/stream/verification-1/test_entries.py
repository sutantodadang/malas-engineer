import io
import json
from contextlib import chdir
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_stream_starts_at_current_position_and_stays_open(self):
        stream = io.StringIO("skip this line\n\n\"café\"\n42\n")
        stream.readline()
        self.assertEqual(read_entries(filename=stream), ["café", 42])
        self.assertFalse(stream.closed)

    def test_invalid_json_propagates_and_stream_stays_open(self):
        stream = io.StringIO("broken")
        with self.assertRaises(json.JSONDecodeError):
            read_entries(stream)
        self.assertFalse(stream.closed)

    def test_file_and_cli_stdin(self):
        data = b'{"one": 1}\n\n42\n'
        cli = Path(__file__).with_name("cli.py").resolve()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "-")
            path.write_bytes(data)
            self.assertEqual(read_entries(filename=path), [{"one": 1}, 42])
            with chdir(directory):
                self.assertEqual(read_entries("-"), [{"one": 1}, 42])
                with self.assertRaises(FileNotFoundError):
                    read_entries("missing.jsonl")
            file_count = subprocess.check_output([sys.executable, cli, "./-"], cwd=directory)
            self.assertEqual(file_count.splitlines(), [b"2"])
            path.unlink()
            pipe_count = subprocess.check_output([sys.executable, cli, "-"], cwd=directory, input=data)
            self.assertEqual(pipe_count, file_count)
