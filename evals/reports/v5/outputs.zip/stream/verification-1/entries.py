import json
from contextlib import nullcontext
from os import PathLike
from pathlib import Path


def read_entries(filename):
    if not isinstance(filename, (str, PathLike)) and hasattr(filename, "read"):
        input_file = nullcontext(filename)
    else:
        input_file = Path(filename).open(encoding="utf-8")
    with input_file as source:
        return [json.loads(line) for line in source if line.strip()]
