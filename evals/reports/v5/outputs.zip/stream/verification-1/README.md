# Entry counter

`python cli.py FILE` counts records in a UTF-8 JSON Lines file. Blank lines are ignored. The public `read_entries(filename)` function also accepts keyword calls and path-like objects. A file literally named `-` is a valid library input.

Use `python cli.py -` to count records from standard input. Passing an open text stream to `read_entries` reads from its current position and leaves the stream open.
