import io
import json
import subprocess
import sys
import unittest
from contextlib import chdir
from pathlib import Path
from tempfile import TemporaryDirectory

from entries import read_entries


CLI = Path(__file__).with_name("cli.py").resolve()
EXPORT = '1\n  \n{"name": "café"}\n'


class EntryTests(unittest.TestCase):
    def test_stream_reads_from_current_position_and_stays_open(self):
        with io.StringIO("header\n" + EXPORT) as source:
            source.readline()
            self.assertEqual(read_entries(filename=source), [1, {"name": "café"}])
            self.assertFalse(source.closed)

    def test_invalid_stream_stays_open(self):
        with io.StringIO("invalid") as source:
            with self.assertRaises(json.JSONDecodeError):
                read_entries(source)
            self.assertFalse(source.closed)

    def test_filename_contract(self):
        with TemporaryDirectory() as directory, chdir(directory):
            Path("-").write_text(EXPORT, encoding="utf-8")
            for filename in ("-", Path("-")):
                self.assertEqual(read_entries(filename=filename), [1, {"name": "café"}])
            Path("-").write_text("invalid", encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError):
                read_entries("-")
            with self.assertRaises(FileNotFoundError):
                read_entries("missing")

    def test_cli_counts_file_and_stdin(self):
        with TemporaryDirectory() as directory:
            path = Path(directory, "export.jsonl")
            path.write_text(EXPORT, encoding="utf-8")
            for arg, data in ((str(path), b""), ("-", EXPORT.encode("utf-8"))):
                result = subprocess.run(
                    [sys.executable, str(CLI), arg], cwd=directory,
                    input=data, capture_output=True, check=True,
                )
                self.assertEqual(result.stdout.splitlines(), [b"2"])
