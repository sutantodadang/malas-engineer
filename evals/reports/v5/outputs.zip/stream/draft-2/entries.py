import json
from contextlib import nullcontext
from os import PathLike
from pathlib import Path


def read_entries(filename):
    if isinstance(filename, (str, PathLike)) or not hasattr(filename, "read"):
        reader = Path(filename).open(encoding="utf-8")
    else:
        reader = nullcontext(filename)
    with reader as source:
        return [json.loads(line) for line in source if line.strip()]
