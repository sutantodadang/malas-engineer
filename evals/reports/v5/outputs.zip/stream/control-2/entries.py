import json
from pathlib import Path


def _parse_entries(source):
    return [json.loads(line) for line in source if line.strip()]


def read_entries(filename):
    if hasattr(filename, "read"):
        return _parse_entries(filename)
    with Path(filename).open(encoding="utf-8") as source:
        return _parse_entries(source)
