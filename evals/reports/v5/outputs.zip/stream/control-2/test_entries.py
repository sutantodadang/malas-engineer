import io
import json
import subprocess
import sys
import tempfile
import unittest
from contextlib import chdir
from pathlib import Path

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_stream_is_borrowed_on_success_and_error(self):
        source = io.StringIO('1\n \n{"id": 2}\n')
        self.assertEqual(read_entries(filename=source), [1, {"id": 2}])
        self.assertFalse(source.closed)
        invalid = io.StringIO("bad json\n")
        with self.assertRaises(json.JSONDecodeError):
            read_entries(invalid)
        self.assertFalse(invalid.closed)

    def test_cli_counts_file_and_stdin(self):
        cli = Path(__file__).with_name("cli.py").resolve()
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp, "export.jsonl")
            content = '"é"\n\n2\n'
            path.write_text(content, encoding="utf-8")
            self.assertEqual(read_entries(filename=path), ["é", 2])
            Path(temp, "-").write_text("42\n", encoding="utf-8")
            with chdir(temp):
                self.assertEqual(read_entries(filename="-"), [42])
            for arg in (path.name, "-"):
                result = subprocess.run(
                    [sys.executable, cli, arg], cwd=temp, input=content if arg == "-" else "",
                    text=True, capture_output=True, check=True,
                )
                self.assertEqual(result.stdout, "2\n")
