import json
from os import PathLike
from pathlib import Path


def read_entries(filename):
    if not isinstance(filename, (str, PathLike)) and hasattr(filename, "read"):
        return _parse_entries(filename)
    with Path(filename).open(encoding="utf-8") as source:
        return _parse_entries(source)


def _parse_entries(source):
    return [json.loads(line) for line in source if line.strip()]
