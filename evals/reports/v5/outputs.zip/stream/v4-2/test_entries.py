import io
import json
import subprocess
import sys
import tempfile
import unittest
from contextlib import chdir
from pathlib import Path

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_borrowed_stream_starts_at_current_position(self):
        with io.StringIO('skip\n\n{"id": 2}\n') as source:
            source.readline()
            self.assertEqual(read_entries(filename=source), [{"id": 2}])
            self.assertFalse(source.closed)

    def test_invalid_json_leaves_stream_open(self):
        with io.StringIO("1\noops") as source:
            with self.assertRaises(json.JSONDecodeError):
                read_entries(source)
            self.assertFalse(source.closed)

    def test_paths_and_cli(self):
        cli = Path(__file__).with_name("cli.py").resolve()
        data = '1\n\n"two"\n'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "export.jsonl")
            path.write_text(data, encoding="utf-8")
            self.assertEqual(read_entries(filename=path), [1, "two"])
            with chdir(directory):
                Path("-").write_text("3\n", encoding="utf-8")
                self.assertEqual(read_entries(filename="-"), [3])
            for argument, stdin in [(str(path), ""), ("-", data)]:
                result = subprocess.run(
                    [sys.executable, str(cli), argument], cwd=directory,
                    input=stdin, text=True, capture_output=True, check=True,
                )
                self.assertEqual(result.stdout, "2\n")
            path.unlink()
            with self.assertRaises(FileNotFoundError):
                read_entries(path)
