import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import chdir
from pathlib import Path

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_stream_ownership_and_parse_errors(self):
        stream = io.StringIO('header\n1\n \n{"n": 2}\n')
        stream.readline()
        self.assertEqual(read_entries(filename=stream), [1, {"n": 2}])
        self.assertFalse(stream.closed)

        malformed = io.StringIO("invalid\n")
        with self.assertRaises(json.JSONDecodeError):
            read_entries(malformed)
        self.assertFalse(malformed.closed)

    def test_file_and_stdin_counts(self):
        content = '"é"\n\n2\n'
        cli = [sys.executable, str(Path(__file__).with_name("cli.py").resolve())]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "-"
            path.write_text(content, encoding="utf-8")
            self.assertEqual(read_entries(filename=path), ["é", 2])
            with chdir(directory):
                self.assertEqual(read_entries(filename="-"), ["é", 2])
            with self.assertRaises(FileNotFoundError):
                read_entries(path.with_name("missing"))
            for argument in (str(path), "-"):
                result = subprocess.run(
                    cli + [argument],
                    input=content.encode(),
                    capture_output=True,
                    check=True,
                    env={**os.environ, "PYTHONIOENCODING": "utf-8"},
                )
                self.assertEqual(result.stdout.strip(), b"2")
