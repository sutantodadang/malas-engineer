import json
from contextlib import nullcontext
from pathlib import Path


def read_entries(filename):
    if hasattr(filename, "read"):
        context = nullcontext(filename)
    else:
        context = Path(filename).open(encoding="utf-8")
    with context as source:
        return [json.loads(line) for line in source if line.strip()]
