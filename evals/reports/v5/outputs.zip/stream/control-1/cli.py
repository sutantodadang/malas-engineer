import argparse
import sys

from entries import read_entries


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("filename")
    args = parser.parse_args(argv)
    source = sys.stdin if args.filename == "-" else args.filename
    print(len(read_entries(source)))


if __name__ == "__main__":
    main()
