import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from entries import read_entries


class EntryTests(unittest.TestCase):
    def test_borrowed_stream_and_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "entries"
            for data in ('"caf\u00e9"\n \t\n42\n', '42\nbad\n'):
                path.write_text(data, encoding="utf-8")
                with io.StringIO(data) as stream:
                    for source in (path, stream):
                        if "bad" in data:
                            with self.assertRaises(json.JSONDecodeError):
                                read_entries(filename=source)
                        else:
                            self.assertEqual(read_entries(filename=source), ["caf\u00e9", 42])
                    self.assertFalse(stream.closed)

    def test_dash_is_a_library_filename(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous = Path.cwd()
            os.chdir(tmp)
            try:
                Path("-").write_text("3", encoding="utf-8")
                self.assertEqual(read_entries(filename="-"), [3])
                with self.assertRaises(FileNotFoundError):
                    read_entries("missing")
            finally:
                os.chdir(previous)

    def test_cli_pipe_matches_file(self):
        env = dict(os.environ, PYTHONIOENCODING="ascii:replace")
        cli = Path(__file__).with_name("cli.py").resolve()
        cases = [
            ('"caf\u00e9"\n\u2003\n42\n'.encode(), None),
            (b"42\nbad\n", b"JSONDecodeError"),
            (b'"\xff"\n', b"UnicodeDecodeError"),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "entries"
            for data, error in cases:
                path.write_bytes(data)
                for argument in (str(path), "-"):
                    with self.subTest(argument=argument, data=data):
                        result = subprocess.run(
                            [sys.executable, "-B", str(cli), argument],
                            input=data, capture_output=True, env=env, cwd=tmp,
                        )
                        if error:
                            self.assertNotEqual(result.returncode, 0)
                            self.assertIn(error, result.stderr)
                        else:
                            self.assertEqual(result.returncode, 0, result.stderr)
                            self.assertEqual(result.stdout.splitlines(), [b"2"])
