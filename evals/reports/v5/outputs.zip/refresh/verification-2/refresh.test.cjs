const { test } = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

test("overlapping refreshes share the default view and later refreshes load again", async () => {
  const loads = [];
  const service = new RefreshService({
    load(key, view) {
      assert.deepEqual([key, view], ["record", "summary"]);
      return new Promise(resolve => loads.push(resolve));
    },
  });
  const first = service.refresh("record");
  const second = service.refresh("record", "summary");
  assert.equal(loads.length, 1);
  const result = {};
  loads[0](result);
  assert.equal(await first, result);
  assert.equal(await second, result);
  const third = service.refresh("record");
  assert.equal(loads.length, 2);
  loads[1]("fresh");
  assert.equal(await third, "fresh");
});

test("arbitrary record and view pairs and separate service instances load independently", async () => {
  let count = 0;
  const store = { load: () => ++count };
  const service = new RefreshService(store);
  const other = new RefreshService(store);
  const results = await Promise.all([
    service.refresh("a:b", "c"),
    service.refresh("a", "b:c"),
    service.refresh("a", "c"),
    other.refresh("a", "c"),
  ]);
  assert.deepEqual(results, [1, 2, 3, 4]);
});

test("both callers receive the original rejection and a retry loads again", async () => {
  const error = new Error("load failed");
  let calls = 0;
  const service = new RefreshService({
    load: () => ++calls === 1 ? Promise.reject(error) : Promise.resolve("recovered"),
  });
  const outcomes = await Promise.allSettled([service.refresh("x"), service.refresh("x")]);
  for (const outcome of outcomes) {
    assert.equal(outcome.status, "rejected");
    assert.equal(outcome.reason, error);
  }
  assert.equal(await service.refresh("x"), "recovered");
  assert.equal(calls, 2);
});
