class RefreshService {
  constructor(store) {
    this.store = store;
    this.inFlight = new Map();
  }

  async refresh(key, view = "summary") {
    const pair = JSON.stringify([key, view]);
    if (!this.inFlight.has(pair)) {
      const pending = Promise.resolve(this.store.load(key, view))
        .finally(() => this.inFlight.delete(pair));
      this.inFlight.set(pair, pending);
    }
    return this.inFlight.get(pair);
  }
}

module.exports = { RefreshService };
