const test = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

function controlledStore() {
  const calls = [];
  return {
    calls,
    load(key, view) {
      return new Promise((resolve, reject) => {
        calls.push({ key, view, resolve, reject });
      });
    },
  };
}

test("concurrent default and summary refreshes share one load until success", async () => {
  const store = controlledStore();
  const service = new RefreshService(store);
  const first = service.refresh("record");
  const second = service.refresh("record", "summary");
  assert.equal(store.calls.length, 1);
  assert.equal(store.calls[0].view, "summary");
  const result = {};
  store.calls[0].resolve(result);
  assert.equal(await first, result);
  assert.equal(await second, result);

  const next = service.refresh("record");
  assert.equal(store.calls.length, 2);
  store.calls[1].resolve("fresh");
  assert.equal(await next, "fresh");
});

test("keys, views, and service instances keep loads independent", async () => {
  const store = controlledStore();
  const service = new RefreshService(store);
  const other = new RefreshService(store);
  const pairs = [["a:b", "c"], ["a", "b:c"], ["a", ""], ["", ""]];
  const pending = pairs.map(([key, view]) => service.refresh(key, view));
  pending.push(other.refresh("a", ""));
  assert.deepEqual(store.calls.map(({ key, view }) => [key, view]), [...pairs, ["a", ""]]);
  store.calls.forEach((call, index) => call.resolve(index));
  assert.deepEqual(await Promise.all(pending), [0, 1, 2, 3, 4]);
});

test("failure reaches both callers and allows the next load", async () => {
  const store = controlledStore();
  const service = new RefreshService(store);
  const error = new Error("store unavailable");
  const failures = [service.refresh("x"), service.refresh("x")].map(pending =>
    assert.rejects(pending, reason => reason === error)
  );
  assert.equal(store.calls.length, 1);
  store.calls[0].reject(error);
  await Promise.all(failures);

  const retry = service.refresh("x");
  assert.equal(store.calls.length, 2);
  store.calls[1].resolve("recovered");
  assert.equal(await retry, "recovered");
});
