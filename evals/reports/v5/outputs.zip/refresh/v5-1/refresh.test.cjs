const { test } = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

test("overlapping summary refreshes share a load, then fetch again", async () => {
  let calls = 0;
  let finish;
  const service = new RefreshService({
    load(key, view) {
      assert.deepEqual([key, view], ["record", "summary"]);
      calls++;
      return new Promise(resolve => { finish = resolve; });
    },
  });
  const first = service.refresh("record");
  const second = service.refresh("record", "summary");
  assert.equal(calls, 1);
  finish("first result");
  assert.deepEqual(await Promise.all([first, second]), ["first result", "first result"]);
  const next = service.refresh("record");
  assert.equal(calls, 2);
  finish("updated");
  assert.equal(await next, "updated");
});

test("services and distinct record/view pairs load independently", async () => {
  const makeService = name => new RefreshService({
    async load(key, view) { return [name, key, view]; },
  });
  const a = makeService("a");
  const b = makeService("b");
  assert.deepEqual(await Promise.all([
    a.refresh("x:y", "z"), a.refresh("x", "y:z"), a.refresh("x", "z"),
    b.refresh("x:y", "z"),
  ]), [["a", "x:y", "z"], ["a", "x", "y:z"], ["a", "x", "z"], ["b", "x:y", "z"]]);
});

test("both callers receive the original failure and can retry", async () => {
  let calls = 0;
  const failure = new Error("store unavailable");
  const service = new RefreshService({
    async load() {
      if (++calls === 1) throw failure;
      return "recovered";
    },
  });
  const results = await Promise.allSettled([service.refresh("key"), service.refresh("key")]);
  for (const result of results) {
    assert.equal(result.status, "rejected");
    assert.equal(result.reason, failure);
  }
  assert.equal(calls, 1);
  assert.equal(await service.refresh("key"), "recovered");
  assert.equal(calls, 2);
});
