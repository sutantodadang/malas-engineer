class RefreshService {
  constructor(store) {
    this.store = store;
    this.inFlight = new Map();
  }

  async refresh(key, view = "summary") {
    const requestKey = JSON.stringify([key, view]);
    if (this.inFlight.has(requestKey)) return this.inFlight.get(requestKey);

    const loading = Promise.resolve(this.store.load(key, view))
      .finally(() => this.inFlight.delete(requestKey));
    this.inFlight.set(requestKey, loading);
    return loading;
  }
}

module.exports = { RefreshService };
