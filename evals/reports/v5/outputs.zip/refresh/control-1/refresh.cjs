class RefreshService {
  constructor(store) {
    this.store = store;
    this.inFlight = new Map();
  }

  async refresh(key, view = "summary") {
    const pair = JSON.stringify([key, view]);
    if (this.inFlight.has(pair)) return this.inFlight.get(pair);

    const load = Promise.resolve(this.store.load(key, view));
    this.inFlight.set(pair, load);
    try {
      return await load;
    } finally {
      this.inFlight.delete(pair);
    }
  }
}

module.exports = { RefreshService };
