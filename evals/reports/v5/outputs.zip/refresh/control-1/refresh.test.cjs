const { test } = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

test("concurrent default and explicit summary share a load, then load again", async () => {
  let calls = 0;
  let finish;
  const service = new RefreshService({
    load(key, view) {
      assert.deepEqual([key, view], ["record", "summary"]);
      calls++;
      return new Promise(resolve => { finish = resolve; });
    },
  });
  const first = service.refresh("record");
  const second = service.refresh("record", "summary");
  assert.equal(calls, 1);
  const result = {};
  finish(result);
  for (const value of await Promise.all([first, second])) assert.equal(value, result);
  const later = service.refresh("record");
  assert.equal(calls, 2);
  finish("fresh");
  assert.equal(await later, "fresh");
});

test("distinct pairs and services keep independent loads", async () => {
  const first = new RefreshService({ load: (...args) => args });
  const second = new RefreshService({ load: () => "other store" });
  assert.deepEqual(await Promise.all([
    first.refresh("a:b", "c"),
    first.refresh("a", "b:c"),
    first.refresh("a:b", "detail"),
    second.refresh("a:b", "c"),
  ]), [["a:b", "c"], ["a", "b:c"], ["a:b", "detail"], "other store"]);
});

test("shared failures preserve the original error and permit retries", async () => {
  const failure = new Error("load failed");
  let calls = 0;
  const service = new RefreshService({
    load() {
      calls++;
      if (calls === 1) return Promise.reject(failure);
      if (calls === 2) throw failure;
      return "recovered";
    },
  });
  const results = await Promise.allSettled([service.refresh("a"), service.refresh("a")]);
  assert.equal(calls, 1);
  for (const result of results) assert.equal(result.reason, failure);
  await assert.rejects(service.refresh("a"), error => error === failure);
  assert.equal(await service.refresh("a"), "recovered");
});
