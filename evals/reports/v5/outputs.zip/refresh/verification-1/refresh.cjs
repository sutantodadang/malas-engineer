class RefreshService {
  constructor(store) {
    this.store = store;
    this.inFlight = new Map();
  }

  async refresh(key, view = "summary") {
    const id = JSON.stringify([key, view]);
    if (this.inFlight.has(id)) return this.inFlight.get(id);

    const pending = Promise.resolve(this.store.load(key, view));
    this.inFlight.set(id, pending);
    try {
      return await pending;
    } finally {
      this.inFlight.delete(id);
    }
  }
}

module.exports = { RefreshService };
