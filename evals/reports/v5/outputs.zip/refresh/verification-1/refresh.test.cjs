const { test } = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

test("overlapping default and summary refreshes share a load until it settles", async () => {
  const loads = [];
  const service = new RefreshService({
    load(key, view) {
      assert.deepEqual([key, view], ["catalog", "summary"]);
      return new Promise(resolve => loads.push(resolve));
    }
  });

  const first = service.refresh("catalog");
  const second = service.refresh("catalog", "summary");
  await Promise.resolve();
  assert.equal(loads.length, 1);
  const record = {};
  loads[0](record);
  assert.equal(await first, record);
  assert.equal(await second, record);

  const next = service.refresh("catalog");
  await Promise.resolve();
  assert.equal(loads.length, 2);
  loads[1]("new result");
  assert.equal(await next, "new result");
});

test("failures reach both callers and permit retry", async () => {
  let attempts = 0;
  const error = new Error("store unavailable");
  const service = new RefreshService({
    async load() {
      if (++attempts === 1) throw error;
      return "recovered";
    }
  });
  const outcomes = await Promise.allSettled([service.refresh("a"), service.refresh("a")]);
  for (const outcome of outcomes) {
    assert.equal(outcome.status, "rejected");
    assert.equal(outcome.reason, error);
  }
  assert.equal(await service.refresh("a"), "recovered");
  assert.equal(attempts, 2);
});

test("different records, views and service instances load independently", async () => {
  const service = new RefreshService({ load: (key, view) => [key, view] });
  const other = new RefreshService({ load: () => "other store" });
  const pairs = [["a:b", "c"], ["a", "b:c"], ["a", "c"], ["a:b", "b:c"]];
  const results = await Promise.all([
    ...pairs.map(([key, view]) => service.refresh(key, view)),
    other.refresh("a:b", "c")
  ]);
  assert.deepEqual(results, [...pairs, "other store"]);
});
