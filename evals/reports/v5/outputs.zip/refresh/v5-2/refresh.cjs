class RefreshService {
  #inFlight = new Map();

  constructor(store) {
    this.store = store;
  }

  async refresh(key, view = "summary") {
    const pair = JSON.stringify([key, view]);
    if (!this.#inFlight.has(pair)) {
      const pending = Promise.resolve(this.store.load(key, view))
        .finally(() => this.#inFlight.delete(pair));
      this.#inFlight.set(pair, pending);
    }
    return this.#inFlight.get(pair);
  }
}

module.exports = { RefreshService };
