const test = require("node:test");
const assert = require("node:assert/strict");
const { RefreshService } = require("./refresh.cjs");

test("overlapping default and summary requests share a load, then fetch again", async () => {
  let count = 0;
  let finish;
  const gate = new Promise(resolve => { finish = resolve; });
  const service = new RefreshService({
    async load(key, view) {
      assert.deepEqual([key, view], ["book", "summary"]);
      const result = { revision: ++count };
      await gate;
      return result;
    },
  });
  const first = service.refresh("book");
  const second = service.refresh("book", "summary");
  finish();
  const [a, b] = await Promise.all([first, second]);
  assert.equal(a, b);
  assert.equal(a.revision, 1);
  assert.equal((await service.refresh("book")).revision, 2);
  assert.equal(count, 2);
});

test("distinct keys, views and service instances have independent loads", async () => {
  const makeService = name => new RefreshService({ load: (key, view) => [name, key, view] });
  const left = makeService("left");
  const right = makeService("right");
  const pairs = [["a:b", "c"], ["a", "b:c"], ["a", "c"], ["a:b", ""]];
  const actual = await Promise.all([
    ...pairs.map(pair => left.refresh(...pair)),
    right.refresh(...pairs[0]),
  ]);
  assert.deepEqual(actual, [...pairs.map(pair => ["left", ...pair]), ["right", ...pairs[0]]]);
});

test("overlapping callers receive the original load failure and can retry", async () => {
  const error = new Error("catalog unavailable");
  let calls = 0;
  const service = new RefreshService({ async load() {
    if (++calls === 1) throw error;
    return "restored";
  } });
  const results = await Promise.allSettled([service.refresh("x"), service.refresh("x")]);
  for (const result of results) {
    assert.equal(result.status, "rejected");
    assert.equal(result.reason, error);
  }
  assert.equal(await service.refresh("x"), "restored");
  assert.equal(calls, 2);
});
